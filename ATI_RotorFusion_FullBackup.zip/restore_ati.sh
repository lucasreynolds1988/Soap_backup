#!/bin/bash

echo "🧠 Starting ATI system restore..."

# Change to home directory
cd ~

# Remove old Soap folder if exists
if [ -d Soap ]; then
  echo "🗑️ Removing existing Soap directory..."
  rm -rf Soap
fi

# Download the latest backup ZIP from GCS
echo "⬇️ Downloading backup ZIP from GCS bucket..."
gsutil cp gs://ati-rotor-fusion/backups/ATI_RotorFusion_FullBackup.zip .

if [ ! -f ATI_RotorFusion_FullBackup.zip ]; then
  echo "❌ Backup ZIP not found after download. Aborting."
  exit 1
fi

# Unzip backup
echo "📦 Unzipping backup..."
unzip -o ATI_RotorFusion_FullBackup.zip

# Remove ZIP after extraction to save space
rm ATI_RotorFusion_FullBackup.zip

# Change into Soap directory
cd Soap

# Launch rotors and services
echo "🚀 Launching rotors..."
python3 spin_up.py

# Run background rotor process (adjust if your system uses a different file)
python3 cloud_stream_relay.py &

echo "✅ ATI system restore complete and running."
