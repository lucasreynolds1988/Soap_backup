# ~/Soap/chat_agent.py

"""
Chat Agent - Oracle AI SOP Interface
Receives natural language from UI and returns AI-generated response.
"""

import sys
import json
from pathlib import Path

QUEUE_DIR = Path.home() / "Soap/agent_queue"
QUEUE_DIR.mkdir(parents=True, exist_ok=True)

def main():
    if len(sys.argv) < 2:
        print(json.dumps({"error": "No message provided"}))
        return

    message = sys.argv[1].strip()
    if not message:
        print(json.dumps({"error": "Empty input"}))
        return

    # Simulate AI response (placeholder logic for actual LLM call)
    response = {
        "reply": f"🧠 Oracle received: '{message}' — SOP analysis underway..."
    }

    print(json.dumps(response))

if __name__ == "__main__":
    main()
