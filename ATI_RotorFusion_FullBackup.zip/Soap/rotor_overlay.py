# ~/Soap/rotor_overlay.py

from datetime import datetime
from pathlib import Path

def log_event(message, log_file):
    """
    Logs a message with a timestamp to the specified log file.
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {message}\n"
    log_path = Path(log_file)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with open(log_path, "a") as log:
        log.write(line)
