# ~/Soap/rotor_overlay.py

from datetime import datetime

def log_event(message, log_file):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {message}\n"
    with open(log_file, "a") as log:
        log.write(line)

cat > ~/Soap/code_red.py

# ~/Soap/code_red.py

import os
import time
import hashlib
from pathlib import Path
from rotor_overlay import log_event

UPLOAD_DIR = Path.home() / "Soap/uploads"
LOG_PATH = Path.home() / "Soap/logs/code_red.log"
THRESHOLD_MB = 80  # Offload if total exceeds 80MB

def calculate_sha256(file_path):
    sha256_hash = hashlib.sha256()
    with open(file_path, "rb") as f:
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)
    return sha256_hash.hexdigest()

def scan_and_offload():
    log_event("🛡️ Starting Code-Red offload scan of upload directory...", LOG_PATH)
    files = list(UPLOAD_DIR.glob("**/*"))
    total_size = sum(f.stat().st_size for f in files if f.is_file())
    total_mb = total_size / (1024 * 1024)

    if total_mb >= THRESHOLD_MB:
        log_event(f"⚠️ Total upload size is {total_mb:.2f} MB. Offloading triggered.", LOG_PATH)
        for file in files:
            if file.is_file():
                sha = calculate_sha256(file)
                log_event(f"🔄 Offloading: {file.name} [SHA256: {sha}]", LOG_PATH)
                file.unlink()  # Delete after simulated offload
        log_event("✅ Offload complete. All large files removed.", LOG_PATH)
    else:
        log_event(f"✅ Code-Red offload complete. Total size: {total_mb:.2f} MB", LOG_PATH)

if __name__ == "__main__":
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    os.makedirs(LOG_PATH.parent, exist_ok=True)
    scan_and_offload()

ls -R ~/Soap > ~/Soap/_file_inventory.txt && cat ~/Soap/_file_inventory.txt

